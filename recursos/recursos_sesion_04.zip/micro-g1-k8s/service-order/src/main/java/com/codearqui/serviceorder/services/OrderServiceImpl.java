package com.codearqui.serviceorder.services;

import com.codearqui.serviceorder.dto.OrderRequest;
import com.codearqui.serviceorder.dto.OrderResponse;
import com.codearqui.serviceorder.model.entity.OrderModel;
import com.codearqui.serviceorder.model.mapper.OrderMapper;
import com.codearqui.serviceorder.proxy.api.InventoryApi;
import com.codearqui.serviceorder.proxy.model.InventoryResponse;
import com.codearqui.serviceorder.repository.OrderRepository;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.reactor.circuitbreaker.operator.CircuitBreakerOperator;
import io.github.resilience4j.reactor.ratelimiter.operator.RateLimiterOperator;
import io.github.resilience4j.reactor.retry.RetryOperator;
import io.github.resilience4j.reactor.timelimiter.TimeLimiterOperator;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.timelimiter.TimeLimiter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Slf4j
@AllArgsConstructor
@Service
public class OrderServiceImpl  implements OrderService {
    private final OrderRepository orderRepository;
    private final InventoryApi inventoryApi;
    private final CircuitBreaker circuitBreaker;
    private final Retry retry;
    private final TimeLimiter timeLimiter;
    private final RateLimiter rateLimiter;

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Override
    public Mono<OrderResponse> createOrder(OrderRequest orderDto) {
        var orderData = OrderMapper.INSTANCE.requestToModel(orderDto);
        orderData.setDateOrder(LocalDateTime.now().toString());
        orderData.setStatusOrder(OrderResponse.StatusEnum.PENDING.getValue());

        return orderRepository.save(orderData)
                .map(OrderMapper.INSTANCE::modelToResponse);
    }

    @Override
    public Mono<OrderResponse> getOrderById(int orderId) {
        return orderRepository.findById(orderId)
                .map(OrderMapper.INSTANCE::modelToResponse);
    }

    @Override
    public Flux<OrderResponse> getList() {
        return orderRepository.findAll()
                .map(OrderMapper.INSTANCE::modelToResponse);
    }

    @Override
    public Mono<OrderResponse> updateOrder(int orderId) {
        return orderRepository.findById(orderId)
                .map(value -> {
                    value.setStatusOrder(OrderResponse.StatusEnum.COMPLETED.getValue());
                    return value;
                })
                .flatMap(value -> invokeServices(value)
                        .map(x -> value)
                        .switchIfEmpty(Mono.empty())) // invocar al servicio
                .flatMap(orderRepository::save)
                .map(OrderMapper.INSTANCE::modelToResponse)
                .doOnSubscribe(value -> log.info("Init updatedeOrder {}", orderId))
                .doOnSuccess(value -> {
                    log.info("Success update {}", value);
                    this.sendMessageKafka(value.getId() + ":" + value.getStatus().getValue());
                })
                .doOnError(value -> log.error("Error update", value));
    }

    private Mono<InventoryResponse> invokeServices(OrderModel value) {
        return inventoryApi.getInventory(value.getCodeProduct())
                .transformDeferred(CircuitBreakerOperator.of(circuitBreaker))
                //.transformDeferred(RetryOperator.of(retry))
                //.transformDeferred(TimeLimiterOperator.of(timeLimiter))
                //.transformDeferred(RateLimiterOperator.of(rateLimiter))
                .onErrorResume(CallNotPermittedException.class, e -> fallbackItems("Circuitbreaker", e));

    }

    private Mono<InventoryResponse> fallbackItems(String description, Throwable e){
        log.error("Resilience invokeservices ", e);
        return Mono.error(e);
    }

    private void sendMessageKafka(String valueNotify){
        this.kafkaTemplate.send("orders-topic", valueNotify);
    }
}