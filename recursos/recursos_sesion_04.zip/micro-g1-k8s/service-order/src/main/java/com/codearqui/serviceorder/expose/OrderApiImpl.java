package com.codearqui.serviceorder.expose;

import com.codearqui.serviceorder.api.OrdenesApiDelegate;
import com.codearqui.serviceorder.dto.OrderRequest;
import com.codearqui.serviceorder.dto.OrderResponse;
import com.codearqui.serviceorder.services.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Component
@Slf4j
@RequiredArgsConstructor
public class OrderApiImpl implements OrdenesApiDelegate {
    private final OrderService orderService;

    /**
     * POST /orders : Registrar una nueva orden
     *
     * @param orderRequest  (required)
     * @return Orden registrada exitosamente (status code 201)
     *         or Solicitud inválida (status code 400)
     *         or Error en el servidor (status code 500)
     * @see OrdenesApi#createOrder
     */
    @Override
    public Mono<OrderResponse> createOrder(Mono<OrderRequest> orderRequest,
                                           ServerWebExchange exchange) {
        return orderRequest.flatMap(orderService::createOrder)
                .doOnSubscribe(value -> log.info("Request init createOrder()"))
                .doOnSuccess(value -> log.info("Request success createOrder(): {}", value))
                .doOnError(value -> log.error("Request Error createOrder()", value));
    }

    /**
     * GET /orders/{orderId} : Obtener una orden específica
     *
     * @param orderId ID de la orden a obtener (required)
     * @return Detalles de la orden recuperados exitosamente (status code 200)
     *         or Orden no encontrada (status code 404)
     *         or Error en el servidor (status code 500)
     * @see OrdenesApi#getOrder
     */
    @Override
    public Mono<OrderResponse> getOrder(Integer orderId,
                                        ServerWebExchange exchange) {
        return orderService.getOrderById(orderId)
                .doOnSuccess(value -> {
                    if (Optional.ofNullable(value).isEmpty()){
                        exchange.getResponse().setStatusCode(HttpStatus.NO_CONTENT);
                    }
                });
    }

    /**
     * GET /orders : Listar todas las órdenes
     *
     * @return Lista de órdenes recuperada exitosamente (status code 200)
     *         or Error en el servidor (status code 500)
     * @see OrdenesApi#listOrders
     */
    @Override
    public Flux<OrderResponse> listOrders(ServerWebExchange exchange) {
        return orderService.getList();
    }

    /**
     * PUT /orders/{orderId} : Actualizar una orden
     *
     * @param orderId ID de la orden a actualizar (required)
     * @return Orden actualizada exitosamente (status code 200)
     *         or Orden no encontrada (status code 404)
     *         or Error en el servidor (status code 500)
     * @see OrdenesApi#updateOrder
     */
    @Override
    public Mono<Void> updateOrder(Integer orderId,
                                  ServerWebExchange exchange) {
        return orderService.updateOrder(orderId)
                .doOnSuccess(value -> {
                    if (Optional.ofNullable(value).isEmpty()) {
                        exchange.getResponse().setStatusCode(HttpStatus.NOT_FOUND);
                    }
                }).then();
    }
}