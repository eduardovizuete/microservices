package com.codearqui.servicenotify.services;

import com.codearqui.servicenotify.dto.NotifyResponse;
import com.codearqui.servicenotify.models.dto.ListeNotify;
import com.codearqui.servicenotify.models.entity.NotifyOrder;
import com.codearqui.servicenotify.repository.NotifyOrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotifyOrderServiceImpl implements NotifyOrderService  {
    private final NotifyOrderRepository notifyRepo;

    @Override
    public Mono<Boolean> saveNotify(ListeNotify listeNotify) {
        var data = new NotifyOrder();
        data.setOwner(listeNotify.owner());
        data.setStatus(listeNotify.status());
        data.setDateString(LocalDateTime.now().toString());
        return notifyRepo.save(data)
                .map(x -> x.getId() != null ? true : false)
                .switchIfEmpty(Mono.just(false))
                .doOnSubscribe(x -> log.info("Init saveNotify data: {}", x))
                .doOnSuccess(x -> log.info("Success saveNotify data: {}", x))
                .doOnError(x -> log.error("Error saveNotify data", x));
    }

    @Override
    public Mono<NotifyResponse> getNotify(String id) {
        return notifyRepo.findById(id)
                .map(x -> new NotifyResponse()
                        .id(x.getId())
                        .owner(x.getOwner())
                        .status(x.isStatus())
                        .dateString(x.getDateString())
                );
    }

    @Override
    public Flux<NotifyResponse> getAllNotify() {
        return notifyRepo.findAll()
                .map(x -> new NotifyResponse()
                        .id(x.getId())
                        .owner(x.getOwner())
                        .status(x.isStatus())
                        .dateString(x.getDateString())
                );
    }
}