package com.codearqui.servicenotify.models.dto;

public record ListeNotify(int id, String owner, boolean status) {
}