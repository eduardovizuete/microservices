package com.codearqui.serviceinventory.service;

import com.codearqui.serviceinventory.dto.InventoryRequest;
import com.codearqui.serviceinventory.model.entity.ProductsModel;
import com.codearqui.serviceinventory.model.mapper.InventoryMapper;
import com.codearqui.serviceinventory.repository.InventoryRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.math.BigDecimal;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventoryServiceImplTest {
    @InjectMocks
    private InventoryServiceImpl inventoryService;
    @Mock
    private InventoryRepository inventoryRepository;

    @Test
    @DisplayName("create order when parameters is correct then return success")
    void createOrderWhenParametersIsCorrectThenReturnSuccess() {
        //Arrange
        var requestInventory = new InventoryRequest()
                .idProduct("123")
                .nameProduct("Reloj")
                .price(BigDecimal.valueOf(100.00))
                .stock(10);
        var productModel = ProductsModel.builder()
                .id(1)
                .code("123")
                .nameProduct("Reloj")
                .stock(10)
                .price(BigDecimal.valueOf(100.00))
                .build();
        var responseInventory = InventoryMapper.INSTANCE.modelToResponse(productModel);

        when(inventoryRepository.existsByCode(anyString()))
                .thenReturn(Mono.just(false));
        when(inventoryRepository.save(any(ProductsModel.class)))
                .thenReturn(Mono.just(productModel));

        //Act
        var result = inventoryService.createOrder(Mono.just(requestInventory));

        //Assert
        StepVerifier.create(result)
                .expectNext(responseInventory)
                .verifyComplete();

        verify(inventoryRepository, times(1)).existsByCode("123");
    }

    @Test
    @DisplayName("get inventory when code is correct then return success")
    void getInventoryWhenCodeIsCorrectThenReturnSuccess() {
        //Arrange
        var productModel = ProductsModel.builder()
                .id(1)
                .code("123")
                .nameProduct("Reloj")
                .stock(10)
                .price(BigDecimal.valueOf(100.00))
                .build();
        var responseInventory = InventoryMapper.INSTANCE.modelToResponse(productModel);

        when(inventoryRepository.findByCode(anyString()))
                .thenReturn(Mono.just(productModel));

        //Act
        var result = inventoryService.getInventory("123");

        //Assert
        StepVerifier.create(result)
                .expectNext(responseInventory)
                .verifyComplete();

        verify(inventoryRepository, times(1)).findByCode("123");
    }

    @Test
    @DisplayName("get list when there are products then return success")
    void getListWhenThereAreProductsThenReturnSuccess() {
        //Arrange
        var productModel = ProductsModel.builder()
                .id(1)
                .code("123")
                .nameProduct("Reloj")
                .stock(10)
                .price(BigDecimal.valueOf(100.00))
                .build();
        var responseInventory = InventoryMapper.INSTANCE.modelToResponse(productModel);
        var responseInventory2 = InventoryMapper.INSTANCE.modelToResponse(productModel);

        when(inventoryRepository.findAll())
                .thenReturn(Flux.just(productModel, productModel));

        //Act
        var result = inventoryService.getList();

        //Assert
        StepVerifier.create(result)
                .expectNext(responseInventory, responseInventory2)
                .verifyComplete();

        verify(inventoryRepository, times(1)).findAll();
    }
}